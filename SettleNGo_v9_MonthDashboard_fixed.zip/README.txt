Settle N Go v5 UI

Updated:
- Floating + button no longer overlaps side icons
- Real center gap layout for the bottom nav
- Quick record still opens from +
- Language switching now updates page labels and category names

Build:
1. npm install
2. npm run dev
3. npm run build
- Custom quick amount presets added

- FAB quick menu added: Expense / Income / Scan / Transfer

- FAB menu icons unified
- Smoother FAB/menu animation
- Long press on + opens quick expense directly

- Monthly dashboard header added
