
import React, { useEffect, useMemo, useRef, useState } from "react";
import { createWorker } from "tesseract.js";

const CURRENCIES = ["MYR","RMB","HKD","USD","SGD","JPY","EUR","GBP","AUD","CAD","CHF","NZD","THB","KRW","INR","IDR","VND","PHP","TWD","AED","SAR","QAR","KWD","BHD","OMR","TRY","ZAR","EGP","PKR","BDT","LKR","NPR","MXN","BRL","ARS","CLP","COP","PEN","RUB","UAH","PLN","CZK","HUF","SEK","NOK","DKK","ILS","NGN","KES","GHS","MAD","RON"];
const CATEGORIES = ["Food","Restaurant","Coffee","Shopping","Entertainment","Movie","Travel","Transport","Fuel","Electronics","Rent","Utilities","Online Shopping","Gift","Medical","Pets","Study","Work","Income","Investment","Other"];
const ACCOUNT_TYPES = ["Bank","Cash","WeChat","Alipay","Touch n Go","Investment","Crypto","Other"];
const QUICK_PRESETS = [
  { amount: 5, currency: "MYR", label: "RM 5" },
  { amount: 10, currency: "MYR", label: "RM 10" },
  { amount: 20, currency: "MYR", label: "RM 20" },
  { amount: 50, currency: "MYR", label: "RM 50" },
  { amount: 10, currency: "RMB", label: "¥ 10" },
  { amount: 20, currency: "RMB", label: "¥ 20" },
  { amount: 50, currency: "RMB", label: "¥ 50" }
];
const DEFAULT = { settings: { language: "English", theme: "tng" }, assets: [], records: [] };

const I18N = {
  English: { home:"Home", assets:"Assets", scan:"Scan", stats:"Stats", record:"Record", income:"Income", expense:"Expense", type:"Type", amount:"Amount", currency:"Currency", account:"Account", category:"Category", note:"Note", selectAccount:"Select account", saveRecord:"Save 🔔", updateRecord:"Update Record 🔔", addUpdateAsset:"Add / Update Asset", assetName:"Asset name", assetType:"Asset type", customAssetType:"Custom Asset Type", assetAmount:"Asset amount", from:"From", to:"To", transfer:"Transfer", reports:"Reports", settings:"Settings", quickServices:"Quick Services", smartAdvice:"Smart Advice", incomeExpenseSummary:"Income / Expense Summary", assetsByCurrency:"Assets by Currency", selectCurrency:"Select Currency", noAssetData:"No asset data yet.", noAssets:"No assets yet.", noRecords:"No records yet.", noExpenseData:"No expense data yet.", allAddedCurrencies:"All Added Currencies", statisticsPeriod:"Statistics Period", resetAllData:"Reset All Data", language:"Language", theme:"Theme", ocrScan:"OCR Scan Receipt / Transfer", ocrMode:"OCR Mode", ocrTips:"OCR Tips", ocrRawText:"OCR Raw Text", useInRecordPage:"Use in Record Page", autoDetect:"Auto Detect", tngMode:"TNG / DuitNow", bankMode:"Bank Transfer", alipayMode:"Alipay", wechatMode:"WeChat Pay", receiptMode:"General Receipt", bestResults:"Best results: clear image, straight angle, strong lighting, English digits and printed text.", settingNote:"OCR runs in the browser and works best with clear printed receipts.", more:"More", light:"Light", tngTheme:"TNG Blue/Green", slogan:"{t.slogan}", quickAmounts:"Quick Amounts", addQuickAmount:"Add Quick Amount", commonAmount:"Common Amount", remove:"Remove", quickMenu:"Quick Menu", addExpense:"Add Expense", addIncome:"Add Income", quickScan:"Quick Scan", quickTransfer:"Transfer" },
  中文: { home:"首页", assets:"资产", scan:"扫描", stats:"统计", record:"记账", income:"收入", expense:"支出", type:"类型", amount:"金额", currency:"货币", account:"账户", category:"类别", note:"备注", selectAccount:"选择账户", saveRecord:"保存 🔔", updateRecord:"更新记录 🔔", addUpdateAsset:"新增 / 更新资产", assetName:"资产名称", assetType:"资产类型", customAssetType:"自定义资产类型", assetAmount:"资产金额", from:"转出", to:"转入", transfer:"转账", reports:"报告", settings:"设置", quickServices:"快捷功能", smartAdvice:"智能建议", incomeExpenseSummary:"收入 / 支出汇总", assetsByCurrency:"按货币显示资产", selectCurrency:"选择货币", noAssetData:"还没有资产数据。", noAssets:"还没有资产。", noRecords:"还没有记录。", noExpenseData:"还没有支出数据。", allAddedCurrencies:"全部已添加货币", statisticsPeriod:"统计周期", resetAllData:"重置全部数据", language:"语言", theme:"主题", ocrScan:"OCR 扫描小票 / 转账", ocrMode:"OCR 模式", ocrTips:"OCR 提示", ocrRawText:"OCR 原始文字", useInRecordPage:"带入记账页面", autoDetect:"自动识别", tngMode:"TNG / DuitNow", bankMode:"银行转账", alipayMode:"支付宝", wechatMode:"微信支付", receiptMode:"通用小票", bestResults:"最佳效果：图片清晰、角度端正、光线充足、印刷体数字与文字。", settingNote:"OCR 在浏览器中运行，清晰的印刷体小票效果最好。", more:"更多", light:"浅色", tngTheme:"TNG 蓝绿", slogan:"更聪明地记账，更轻松地生活", quickAmounts:"快捷金额", addQuickAmount:"新增快捷金额", commonAmount:"常用金额", remove:"删除", quickMenu:"快捷菜单", addExpense:"新增支出", addIncome:"新增收入", quickScan:"快速扫描", quickTransfer:"转账" },
  "Bahasa Melayu": { home:"Utama", assets:"Aset", scan:"Imbas", stats:"Statistik", record:"Catat", income:"Pendapatan", expense:"Perbelanjaan", type:"Jenis", amount:"Amaun", currency:"Mata Wang", account:"Akaun", category:"Kategori", note:"Nota", selectAccount:"Pilih akaun", saveRecord:"Simpan 🔔", updateRecord:"Kemas Kini Rekod 🔔", addUpdateAsset:"Tambah / Kemas Kini Aset", assetName:"Nama aset", assetType:"Jenis aset", customAssetType:"Jenis aset tersuai", assetAmount:"Amaun aset", from:"Dari", to:"Ke", transfer:"Pindahan", reports:"Laporan", settings:"Tetapan", quickServices:"Akses Pantas", smartAdvice:"Cadangan Pintar", incomeExpenseSummary:"Ringkasan Pendapatan / Perbelanjaan", assetsByCurrency:"Aset Mengikut Mata Wang", selectCurrency:"Pilih mata wang", noAssetData:"Tiada data aset lagi.", noAssets:"Tiada aset lagi.", noRecords:"Tiada rekod lagi.", noExpenseData:"Tiada data perbelanjaan lagi.", allAddedCurrencies:"Semua mata wang ditambah", statisticsPeriod:"Tempoh Statistik", resetAllData:"Reset Semua Data", language:"Bahasa", theme:"Tema", ocrScan:"Imbas OCR Resit / Pindahan", ocrMode:"Mod OCR", ocrTips:"Tip OCR", ocrRawText:"Teks Asal OCR", useInRecordPage:"Guna dalam Halaman Catat", autoDetect:"Auto Kesan", tngMode:"TNG / DuitNow", bankMode:"Pindahan Bank", alipayMode:"Alipay", wechatMode:"WeChat Pay", receiptMode:"Resit Umum", bestResults:"Hasil terbaik: imej jelas, sudut lurus, pencahayaan baik, digit dan teks bercetak.", settingNote:"OCR berjalan dalam pelayar dan paling sesuai untuk resit bercetak yang jelas.", more:"Lagi", light:"Terang", tngTheme:"TNG Biru/Hijau", slogan:"Urus lebih bijak, bergerak lebih pantas", quickAmounts:"Amaun Pantas", addQuickAmount:"Tambah Amaun Pantas", commonAmount:"Amaun Biasa", remove:"Buang", quickMenu:"Menu Pantas", addExpense:"Tambah Belanja", addIncome:"Tambah Pendapatan", quickScan:"Imbas Pantas", quickTransfer:"Pindahan" }
};
const CATEGORY_LABELS = {
  English: {Food:"Food", Restaurant:"Restaurant", Coffee:"Coffee", Shopping:"Shopping", Entertainment:"Entertainment", Movie:"Movie", Travel:"Travel", Transport:"Transport", Fuel:"Fuel", Electronics:"Electronics", Rent:"Rent", Utilities:"Utilities", "Online Shopping":"Online Shopping", Gift:"Gift", Medical:"Medical", Pets:"Pets", Study:"Study", Work:"Work", Income:"Income", Investment:"Investment", Other:"Other"},
  中文: {Food:"饮食", Restaurant:"餐厅", Coffee:"咖啡", Shopping:"购物", Entertainment:"娱乐", Movie:"电影", Travel:"旅行", Transport:"交通", Fuel:"油费", Electronics:"电子产品", Rent:"租金", Utilities:"水电网", "Online Shopping":"网购", Gift:"礼物", Medical:"医疗", Pets:"宠物", Study:"学习", Work:"工作", Income:"收入", Investment:"投资", Other:"其他"},
  "Bahasa Melayu": {Food:"Makanan", Restaurant:"Restoran", Coffee:"Kopi", Shopping:"Membeli-belah", Entertainment:"Hiburan", Movie:"Filem", Travel:"Perjalanan", Transport:"Pengangkutan", Fuel:"Minyak", Electronics:"Elektronik", Rent:"Sewa", Utilities:"Utiliti", "Online Shopping":"Beli-belah Online", Gift:"Hadiah", Medical:"Perubatan", Pets:"Haiwan Peliharaan", Study:"Belajar", Work:"Kerja", Income:"Pendapatan", Investment:"Pelaburan", Other:"Lain-lain"}
};
function categoryLabel(key, lang) { return CATEGORY_LABELS[lang]?.[key] || key; }


function useLocalState(key, initialValue) {
  const [value, setValue] = useState(() => {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : initialValue;
  });
  useEffect(() => { localStorage.setItem(key, JSON.stringify(value)); }, [key, value]);
  return [value, setValue];
}
function fmtDate(iso) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function inPeriod(iso, period) {
  if (period === "all") return true;
  const d = new Date(iso);
  const now = new Date();
  if (period === "day") return d.toDateString() === now.toDateString();
  if (period === "month") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  if (period === "year") return d.getFullYear() === now.getFullYear();
  const first = new Date(now);
  first.setDate(now.getDate() - first.getDay());
  first.setHours(0, 0, 0, 0);
  const last = new Date(first);
  last.setDate(first.getDate() + 7);
  return d >= first && d < last;
}
function LogoBadge() {

  function addCustomPreset() {
    const amount = Number(presetForm.amount);
    if (!amount) return;
    const currency = presetForm.currency;
    const label = `${currency === "MYR" ? "RM" : currency === "RMB" ? "¥" : currency + " "}${amount}`;
    const exists = customPresets.some(p => Number(p.amount) === amount && p.currency === currency);
    if (exists) return;
    setCustomPresets(prev => [...prev, { id: Date.now(), amount, currency, label }]);
    setPresetForm({ amount: "", currency: currency });
  }
  function removeCustomPreset(id) {
    setCustomPresets(prev => prev.filter(p => p.id !== id));
  }
  const allPresets = [...QUICK_PRESETS, ...customPresets];

  return (
    <div className="logoWrap">
      <svg viewBox="0 0 128 128" fill="none">
        <defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#0A84FF" /><stop offset="100%" stopColor="#1ED7A5" /></linearGradient></defs>
        <rect x="16" y="22" width="96" height="80" rx="22" fill="url(#g)" />
        <path d="M36 46h56a8 8 0 0 1 8 8v8H28v-8a8 8 0 0 1 8-8Z" fill="rgba(255,255,255,0.22)" />
        <rect x="48" y="58" width="10" height="22" rx="3" fill="white" />
        <rect x="62" y="50" width="10" height="30" rx="3" fill="white" />
        <rect x="76" y="42" width="10" height="38" rx="3" fill="white" />
        <path d="M46 86c10-2 20-6 28-12 8-6 13-12 17-18" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" />
        <path d="M86 58h10v10" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}
function assetIcon(type) {
  const map = { Bank: "🏦", Cash: "💵", WeChat: "🟢", Alipay: "🔵", "Touch n Go": "🟦", Investment: "📈", Crypto: "🪙", Other: "💼" };
  return map[type] || "💼";
}
function categoryIcon(cat) {
  const map = { Food:"🍜", Restaurant:"🍔", Coffee:"☕", Shopping:"🛒", Entertainment:"🎮", Movie:"🎬", Travel:"✈️", Transport:"🚗", Fuel:"⛽", Electronics:"📱", Rent:"🏠", Utilities:"💡", "Online Shopping":"📦", Gift:"🎁", Medical:"💊", Pets:"🐶", Study:"📚", Work:"💼", Income:"💰", Investment:"📈", Other:"📝" };
  return map[cat] || "📝";
}

function normalizeMoney(raw) {
  if (!raw) return "";
  let s = String(raw).replace(/[^\d.,]/g, "");
  const hasDot = s.includes(".");
  const hasComma = s.includes(",");
  if (hasDot && hasComma) {
    if (s.lastIndexOf(".") > s.lastIndexOf(",")) s = s.replace(/,/g, "");
    else s = s.replace(/\./g, "").replace(",", ".");
  } else if (hasComma && !hasDot) {
    if ((s.match(/,/g) || []).length === 1 && s.split(",")[1].length <= 2) s = s.replace(",", ".");
    else s = s.replace(/,/g, "");
  }
  const n = Number(s);
  return Number.isFinite(n) ? n.toFixed(2) : "";
}
function scoreAmountCandidate(line, value) {
  let score = 0;
  const clean = String(line || "");
  const digits = String(value || "").replace(/[^\d]/g, "");
  if (!digits) return -999;
  if (digits.length >= 7) score -= 12;
  if (digits.length >= 10) score -= 20;
  if (/total amount|amount paid|paid amount|grand total|total/i.test(clean)) score += 15;
  if (/\brm\b|\bmyr\b|¥|\brmb\b|\bhkd\b|\busd\b|hk\$/i.test(clean)) score += 10;
  if (/ref|reference|receipt no|transaction id|trx|qr|account|merchant|beneficiary|phone|tel|order/i.test(clean)) score -= 12;
  if (/successful|receipt|completed|paid to|duitnow/i.test(clean)) score += 2;
  const num = Number(normalizeMoney(value));
  if (Number.isFinite(num)) {
    if (num <= 0) score -= 10;
    if (num > 0 && num < 10000) score += 4;
    if (num >= 100000) score -= 10;
  }
  return score;
}
function parseOCRText(text, mode = "auto") {
  const original = String(text || "");
  const compact = original.replace(/\s+/g, " ").trim();
  const lines = original.split("\n").map(v => v.trim()).filter(Boolean);

  const currency =
    /\bHKD\b|HK\$/i.test(compact) ? "HKD" :
    /\bUSD\b|US\$/i.test(compact) ? "USD" :
    /\bRMB\b|\bCNY\b|¥/i.test(compact) ? "RMB" :
    /\bMYR\b|\bRM\b/i.test(compact) ? "MYR" :
    "MYR";

  let category = "Other";
  if (/fuel|petrol|shell|petronas|caltex|esso/i.test(compact)) category = "Fuel";
  else if (/restaurant|food|rice|noodle|mee|kfc|mcd|starbucks|coffee|cafe/i.test(compact)) category = "Food";
  else if (/grab|uber|taxi|lrt|mrt|transport|touch n go|tng/i.test(compact)) category = "Transport";
  else if (/shop|shopping|mall|store|mart/i.test(compact)) category = "Shopping";

  if (mode === "tng" || /touch n go|tng ewallet|duitnow|paid to|successful/i.test(compact)) category = "Transport";
  if (mode === "alipay" || /alipay/i.test(compact)) category = "Other";
  if (mode === "wechat" || /wechat/i.test(compact)) category = "Other";
  if (mode === "bank" || /bank|beneficiary|duitnow/i.test(compact)) category = "Other";

  const candidates = [];
  const moneyRegex = /(?:RM|MYR|RMB|CNY|HKD|USD|US\$|HK\$|¥)?\s*([0-9]{1,6}(?:[.,][0-9]{1,3})*(?:[.,][0-9]{2})?)/gi;

  for (const line of lines) {
    for (const m of line.matchAll(moneyRegex)) {
      const raw = m[1];
      const normalized = normalizeMoney(raw);
      if (!normalized) continue;
      candidates.push({ line, value: normalized, score: scoreAmountCandidate(line, raw) });
    }
  }
  if (!candidates.length) {
    for (const m of compact.matchAll(moneyRegex)) {
      const raw = m[1];
      const normalized = normalizeMoney(raw);
      if (!normalized) continue;
      candidates.push({ line: compact, value: normalized, score: scoreAmountCandidate(compact, raw) });
    }
  }
  candidates.sort((a, b) => b.score - a.score);
  let amount = candidates[0]?.value || "";

  const targetedPatterns = [
    /total amount[^0-9]{0,20}([0-9]+(?:[.,][0-9]{2})?)/i,
    /amount paid[^0-9]{0,20}([0-9]+(?:[.,][0-9]{2})?)/i,
    /\brm\s*([0-9]+(?:[.,][0-9]{2})?)/i,
    /¥\s*([0-9]+(?:[.,][0-9]{2})?)/i,
  ];
  for (const p of targetedPatterns) {
    const m = compact.match(p);
    if (m) {
      const n = normalizeMoney(m[1]);
      if (n) { amount = n; break; }
    }
  }

  let note = lines.slice(0, 4).join(" / ").slice(0, 140);
  const merchantLine = lines.find(v => /paid to|merchant|beneficiary|store|shop|restaurant|cafe/i.test(v));
  if (merchantLine) note = merchantLine.slice(0, 140);

  return { amount, currency, category, note, rawText: original };
}




function BottomNav({ tab, setTab, t, fabMenuOpen, setFabMenuOpen, setRecordForm }) {
  const items = [
    ["dashboard", "🏠", t.home],
    ["assets", "💼", t.assets],
    ["scan", "📷", t.scan],
    ["stats", "📈", t.stats]
  ];
  let pressTimer = null;
  function goExpense() {
    setRecordForm(prev => ({ ...prev, type: "Expense" }));
    setTab("record");
    setFabMenuOpen(false);
  }
  function goIncome() {
    setRecordForm(prev => ({ ...prev, type: "Income" }));
    setTab("record");
    setFabMenuOpen(false);
  }
  function goScan() {
    setTab("scan");
    setFabMenuOpen(false);
  }
  function goTransfer() {
    setTab("assets");
    setFabMenuOpen(false);
  }
  function startPress() {
    pressTimer = setTimeout(() => {
      goExpense();
    }, 550);
  }
  function cancelPress() {
    if (pressTimer) clearTimeout(pressTimer);
  }
  return (
    <>
      {fabMenuOpen && (
        <>
          <div className="fabOverlay" onClick={() => setFabMenuOpen(false)} />
          <div className="fabMenu">
            <button className="fabMenuItem fabMenuExpense" onClick={goExpense}><span className="fabMiniIcon">−</span><span>{t.addExpense}</span></button>
            <button className="fabMenuItem fabMenuIncome" onClick={goIncome}><span className="fabMiniIcon">+</span><span>{t.addIncome}</span></button>
            <button className="fabMenuItem fabMenuScan" onClick={goScan}><span className="fabMiniIcon">⌁</span><span>{t.quickScan}</span></button>
            <button className="fabMenuItem fabMenuTransfer" onClick={goTransfer}><span className="fabMiniIcon">↹</span><span>{t.quickTransfer}</span></button>
          </div>
        </>
      )}
      <button
        className="fabButton"
        onClick={() => setFabMenuOpen(v => !v)}
        onMouseDown={startPress}
        onMouseUp={cancelPress}
        onMouseLeave={cancelPress}
        onTouchStart={startPress}
        onTouchEnd={cancelPress}
        aria-label="Quick record"
      >
        <span className={`fabPlus ${fabMenuOpen ? "fabPlusOpen" : ""}`}>+</span>
      </button>
      <div className="bottomNavV5">
        <div className="bottomGroup leftGroup">
          {items.slice(0,2).map(([key, icon, label]) => (
            <button key={key} className={`bottomBtnV5 ${tab === key ? "activeBottomV5" : ""}`} onClick={() => setTab(key)}>
              <div className="bottomIconV5">{icon}</div>
              <div className="bottomLabelV5">{label}</div>
            </button>
          ))}
        </div>
        <div className="fabGap" />
        <div className="bottomGroup rightGroup">
          {items.slice(2).map(([key, icon, label]) => (
            <button key={key} className={`bottomBtnV5 ${tab === key ? "activeBottomV5" : ""}`} onClick={() => setTab(key)}>
              <div className="bottomIconV5">{icon}</div>
              <div className="bottomLabelV5">{label}</div>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}


function SimpleBarChart({ title, data, colorClass = "barBlue", empty = "No data yet." }) {
  const entries = Object.entries(data || {}).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const max = entries.length ? Math.max(...entries.map(([, v]) => Number(v) || 0), 1) : 1;
  return (
    <div className="card">
      <h3>{title}</h3>
      {!entries.length ? <div className="info">{empty}</div> : (
        <div className="chartList">
          {entries.map(([label, value]) => (
            <div key={label} className="chartRow">
              <div className="chartTop">
                <span className="badge">{categoryIcon(label)} {label}</span>
                <strong>{value}</strong>
              </div>
              <div className="chartTrack">
                <div className={`chartBar ${colorClass}`} style={{ width: `${Math.max(8, (Number(value) / max) * 100)}%` }} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [settings, setSettings] = useLocalState("settle-settings", DEFAULT.settings);
  const t = I18N[settings.language] || I18N.English;
  const now = new Date();
  const monthLabel = now.toLocaleString(settings.language === "中文" ? "zh-CN" : settings.language === "Bahasa Melayu" ? "ms-MY" : "en-US", { month: "long", year: "numeric" });

  const monthIncomeTotal = records
    .filter(r => {
      const d = new Date(r.createdAt);
      return r.type === "Income" && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((a, r) => a + Number(r.amount || 0), 0);
  const monthExpenseTotal = records
    .filter(r => {
      const d = new Date(r.createdAt);
      return r.type === "Expense" && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((a, r) => a + Number(r.amount || 0), 0);

  const [assets, setAssets] = useLocalState("settle-assets", DEFAULT.assets);
  const [records, setRecords] = useLocalState("settle-records", DEFAULT.records);
  const [tab, setTab] = useState("dashboard");
  const [period, setPeriod] = useState("all");
  const [search, setSearch] = useState("");
  const [statsPeriod, setStatsPeriod] = useState("all");
  const [dashboardCurrency, setDashboardCurrency] = useState("all");
  const [editingRecordId, setEditingRecordId] = useState(null);
  const [editingAssetId, setEditingAssetId] = useState(null);
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [scanPreview, setScanPreview] = useState("");
  const [scanResult, setScanResult] = useState({ amount: "", currency: "", category: "", note: "", rawText: "" });
  const [ocrBusy, setOcrBusy] = useState(false);
  const [ocrProgress, setOcrProgress] = useState("");
  const [ocrMode, setOcrMode] = useState("auto");
  const [assetForm, setAssetForm] = useState({ name: "", type: "Bank", currency: "MYR", amount: "", customType: "" });
  const [transferForm, setTransferForm] = useState({ from: "", to: "", amount: "" });
  const [recordForm, setRecordForm] = useState({ type: "Expense", amount: "", currency: "MYR", account: "", category: "Food", note: "", customCategory: "" });
  const [customPresets, setCustomPresets] = useLocalState("settle-custom-presets", []);
  const [presetForm, setPresetForm] = useState({ amount: "", currency: "MYR" });
  const [fabMenuOpen, setFabMenuOpen] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/service-worker.js").catch(() => {});
    const handler = (e) => { e.preventDefault(); setDeferredPrompt(e); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const currencyOptions = useMemo(() => Array.from(new Set(assets.map(a => a.currency))), [assets]);

  const filteredRecords = useMemo(() => {
    return records.filter(r => inPeriod(r.createdAt, period)).filter(r => {
      const q = search.trim().toLowerCase();
      if (!q) return true;
      return [r.type, r.amount, r.currency, r.account, r.category, r.note, fmtDate(r.createdAt)].join(" ").toLowerCase().includes(q);
    });
  }, [records, period, search]);

  const dashboardRecords = useMemo(() => dashboardCurrency === "all" ? records : records.filter(r => r.currency === dashboardCurrency), [records, dashboardCurrency]);
  const totalsByCurrency = useMemo(() => {
    const out = {};
    assets.forEach(a => { out[a.currency] = (out[a.currency] || 0) + Number(a.amount || 0); });
    return out;
  }, [assets]);
  const totalIncome = dashboardRecords.filter(r => r.type === "Income").reduce((a, r) => a + Number(r.amount || 0), 0);
  const totalExpense = dashboardRecords.filter(r => r.type === "Expense").reduce((a, r) => a + Number(r.amount || 0), 0);

  const spendingByCategory = useMemo(() => {
    const out = {};
    records.filter(r => inPeriod(r.createdAt, statsPeriod) && r.type === "Expense").forEach(r => { out[r.category] = (out[r.category] || 0) + Number(r.amount || 0); });
    return out;
  }, [records, statsPeriod]);

  const currencyFlow = useMemo(() => {
    const out = {};
    records.filter(r => inPeriod(r.createdAt, statsPeriod)).forEach(r => {
      const cur = r.currency || "MYR";
      if (!out[cur]) out[cur] = 0;
      out[cur] += r.type === "Income" ? Number(r.amount || 0) : -Number(r.amount || 0);
    });
    return out;
  }, [records, statsPeriod]);

  const reportIncome = records.filter(r => r.type === "Income").reduce((a, r) => a + Number(r.amount || 0), 0);
  const reportExpense = records.filter(r => r.type === "Expense").reduce((a, r) => a + Number(r.amount || 0), 0);
  const reportRate = reportIncome > 0 ? Math.round(((reportIncome - reportExpense) / reportIncome) * 100) : 0;

  const advice = useMemo(() => {
    const food = records.filter(r => r.type === "Expense" && r.category === "Food").reduce((a, r) => a + Number(r.amount || 0), 0);
    if (!records.length) return "Start adding records to receive smarter spending suggestions.";
    if (reportIncome > 0 && food / reportIncome > 0.25) return "Food spending is above 25% of income. Consider reducing dining out.";
    if (reportIncome > 0 && reportRate < 20) return `Savings rate is ${reportRate}%. Try aiming for 20%.`;
    return "Your spending pattern looks balanced. Keep tracking consistently.";
  }, [records, reportIncome, reportRate]);

  function playRecordSound() {
    try {
      const audio = new Audio("https://actions.google.com/sounds/v1/cash/cash_register.ogg");
      audio.volume = 0.85;
      audio.play().catch(() => {});
    } catch {}
  }

  function saveAsset() {
    const name = assetForm.name.trim();
    const amount = Number(assetForm.amount);
    if (!name || !amount) return;
    const type = assetForm.type === "Other" ? (assetForm.customType.trim() || "Other") : assetForm.type;
    if (editingAssetId) {
      setAssets(prev => prev.map(a => a.id === editingAssetId ? { ...a, name, type, currency: assetForm.currency, amount } : a));
      setEditingAssetId(null);
    } else {
      setAssets(prev => [...prev, { id: Date.now(), name, type, currency: assetForm.currency, amount }]);
    }
    setAssetForm({ name: "", type: "Bank", currency: "MYR", amount: "", customType: "" });
  }
  function editAsset(asset) {
    setEditingAssetId(asset.id);
    setAssetForm({ name: asset.name, type: ACCOUNT_TYPES.includes(asset.type) ? asset.type : "Other", currency: asset.currency, amount: String(asset.amount), customType: ACCOUNT_TYPES.includes(asset.type) ? "" : asset.type });
    setTab("assets");
  }
  function deleteAsset(id) { setAssets(prev => prev.filter(a => a.id !== id)); }

  function saveRecord() {
    const type = recordForm.type;
    const amount = Number(recordForm.amount);
    if (!amount) return;
    const category = recordForm.category === "Other" ? (recordForm.customCategory.trim() || "Other") : recordForm.category;
    if (type === "Expense" && recordForm.account && !editingRecordId) {
      const selectedAsset = assets.find(a => a.name === recordForm.account);
      if (selectedAsset && Number(selectedAsset.amount || 0) < amount) {
        alert(`Insufficient balance in ${selectedAsset.name}. Available: ${selectedAsset.currency} ${selectedAsset.amount}`);
        return;
      }
    }
    if (editingRecordId) {
      const oldRecord = records.find(r => r.id === editingRecordId);
      if (type === "Expense" && recordForm.account) {
        const selectedAsset = assets.find(a => a.name === recordForm.account);
        const refundToOld = oldRecord && oldRecord.account === recordForm.account && oldRecord.type === "Expense" ? Number(oldRecord.amount || 0) : 0;
        const currentBalance = Number(selectedAsset?.amount || 0) + refundToOld;
        if (selectedAsset && currentBalance < amount) {
          alert(`Insufficient balance in ${selectedAsset.name}. Available after adjustment: ${selectedAsset.currency} ${currentBalance}`);
          return;
        }
      }
      setRecords(prev => prev.map(r => r.id === editingRecordId ? { ...r, type, amount, currency: recordForm.currency, account: recordForm.account, category, note: recordForm.note } : r));
      if (oldRecord && oldRecord.account) {
        setAssets(prev => prev.map(a => {
          if (a.name !== oldRecord.account && a.name !== recordForm.account) return a;
          let next = Number(a.amount || 0);
          if (a.name === oldRecord.account) {
            if (oldRecord.type === "Expense") next += Number(oldRecord.amount || 0);
            if (oldRecord.type === "Income") next -= Number(oldRecord.amount || 0);
          }
          if (a.name === recordForm.account) {
            if (type === "Expense") next -= amount;
            if (type === "Income") next += amount;
          }
          return { ...a, amount: next };
        }));
      }
      setEditingRecordId(null);
    } else {
      setRecords(prev => [{ id: Date.now(), createdAt: new Date().toISOString(), type, amount, currency: recordForm.currency, account: recordForm.account, category, note: recordForm.note }, ...prev]);
      if (recordForm.account) {
        setAssets(prev => prev.map(a => a.name !== recordForm.account ? a : { ...a, amount: type === "Expense" ? Number(a.amount) - amount : Number(a.amount) + amount }));
      }
    }
    setRecordForm(prev => ({ ...prev, type: "Expense", amount: "", note: "", customCategory: "" }));
    playRecordSound();
  }
  function editRecord(record) {
    setEditingRecordId(record.id);
    setRecordForm({ type: record.type, amount: String(record.amount), currency: record.currency, account: record.account || "", category: CATEGORIES.includes(record.category) ? record.category : "Other", note: record.note || "", customCategory: CATEGORIES.includes(record.category) ? "" : record.category });
    setTab("record");
  }
  function deleteRecord(id) {
    const target = records.find(r => r.id === id);
    if (target && target.account) {
      setAssets(prev => prev.map(a => a.name !== target.account ? a : { ...a, amount: target.type === "Expense" ? Number(a.amount) + Number(target.amount) : Number(a.amount) - Number(target.amount) }));
    }
    setRecords(prev => prev.filter(r => r.id !== id));
  }
  function transferAsset() {
    const amount = Number(transferForm.amount);
    if (!transferForm.from || !transferForm.to || !amount || transferForm.from === transferForm.to) return;
    const fromAsset = assets.find(a => a.name === transferForm.from);
    const toAsset = assets.find(a => a.name === transferForm.to);
    if (!fromAsset || !toAsset) return;
    if (fromAsset.currency !== toAsset.currency) return alert("Transfer only supports same currency accounts.");
    if (Number(fromAsset.amount) < amount) return alert(`Insufficient balance in ${fromAsset.name}. Available: ${fromAsset.currency} ${fromAsset.amount}`);
    setAssets(prev => prev.map(a => a.name === transferForm.from ? { ...a, amount: Number(a.amount) - amount } : a.name === transferForm.to ? { ...a, amount: Number(a.amount) + amount } : a));
    setRecords(prev => [
      { id: Date.now(), createdAt: new Date().toISOString(), type: "Expense", amount, currency: fromAsset.currency, account: fromAsset.name, category: "Other", note: `Transfer to ${toAsset.name}` },
      { id: Date.now() + 1, createdAt: new Date().toISOString(), type: "Income", amount, currency: toAsset.currency, account: toAsset.name, category: "Other", note: `Transfer from ${fromAsset.name}` },
      ...prev
    ]);
    setTransferForm({ from: "", to: "", amount: "" });
  }
  function resetAllData() {
    setAssets([]); setRecords([]); setSettings({ language: "English", theme: "tng" });
    setAssetForm({ name: "", type: "Bank", currency: "MYR", amount: "", customType: "" });
    setRecordForm({ type: "Expense", amount: "", currency: "MYR", account: "", category: "Food", note: "", customCategory: "" });
    setTransferForm({ from: "", to: "", amount: "" });
    setEditingAssetId(null); setEditingRecordId(null);
    localStorage.removeItem("settle-assets"); localStorage.removeItem("settle-records"); localStorage.removeItem("settle-settings");
    setTab("dashboard");
  }
  function exportCsv() {
    const rows = ["date,type,amount,currency,account,category,note"];
    records.forEach(r => rows.push([fmtDate(r.createdAt), r.type, r.amount, r.currency, `"${r.account || ""}"`, `"${r.category || ""}"`, `"${(r.note || "").replaceAll('"', '""')}"`].join(",")));
    const blob = new Blob([rows.join("\\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "settle-n-go-records.csv"; a.click();
    URL.revokeObjectURL(url);
  }
  async function installApp() {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
  }
  async function onScanFileChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setScanPreview(URL.createObjectURL(file));
    setTab("scan");
    setOcrBusy(true);
    setOcrProgress("Preparing OCR...");
    try {
      const worker = await createWorker("eng", 1, {
        logger: (m) => {
          if (m.status) setOcrProgress(`${m.status}${m.progress ? ` ${Math.round(m.progress * 100)}%` : ""}`);
        },
      });
      const { data } = await worker.recognize(file);
      await worker.terminate();
      const parsed = parseOCRText(data.text || "", ocrMode);
      setScanResult(parsed);
      setOcrProgress("OCR completed");
    } catch (err) {
      setOcrProgress("OCR failed, using fallback parser");
      const name = file.name.toLowerCase();
      let amount = "12.90", currency = "MYR", category = ocrMode === "tng" ? "Transport" : "Food", note = file.name || "Scanned receipt";
      if (name.includes("alipay")) { currency = "RMB"; note = "Alipay transfer"; category = "Other"; amount = "50"; }
      else if (name.includes("wechat")) { currency = "RMB"; note = "WeChat payment"; category = "Other"; amount = "20"; }
      else if (name.includes("tng") || name.includes("touch")) { currency = "MYR"; note = "Touch n Go transaction"; category = "Transport"; amount = "15"; }
      else if (name.includes("bank") || name.includes("transfer")) { currency = "MYR"; note = "Bank transfer"; category = "Other"; amount = "100"; }
      setScanResult({ amount, currency, category, note, rawText: "" });
    } finally {
      setOcrBusy(false);
    }
  }
  function applyScanToRecord() {
    setRecordForm(prev => ({ ...prev, amount: scanResult.amount || "", currency: scanResult.currency || "MYR", category: CATEGORIES.includes(scanResult.category) ? scanResult.category : "Other", customCategory: CATEGORIES.includes(scanResult.category) ? "" : (scanResult.category || ""), note: scanResult.note || "" }));
    setTab("record");
  }

  return (
    <div className="app">
      <div className="hero">
        <div className="heroInner">
          <div className="heroTop">
            <LogoBadge />
            <div><div className="heroTitle">Settle N Go</div><div className="heroSub">{t.slogan}</div>
<div className="monthHeader">
  <div className="monthTitle">{monthLabel}</div>
  <div className="monthStats">
    <div><span>{t.income}</span><strong>{monthIncomeTotal}</strong></div>
    <div><span>{t.expense}</span><strong>{monthExpenseTotal}</strong></div>
  </div>
</div>
</div>
          </div>
          <div className="heroGrid">
            <div className="heroStat"><div className="heroStatLabel">Income</div><div className="heroStatValue">{dashboardCurrency === "all" ? totalIncome : `${dashboardCurrency} ${totalIncome}`}</div></div>
            <div className="heroStat"><div className="heroStatLabel">Expense</div><div className="heroStatValue">{dashboardCurrency === "all" ? totalExpense : `${dashboardCurrency} ${totalExpense}`}</div></div>
          </div>
        </div>
      </div>

      {tab === "dashboard" && <>
        <div className="card">
          <h3>{t.assetsByCurrency}</h3>
          {Object.entries(totalsByCurrency).length === 0 ? <div className="info">{t.noAssetData}</div> :
            Object.entries(totalsByCurrency).map(([c, a]) => <div className="sumRow" key={c}><span>{c}</span><strong style={{color:"#0057ff"}}>{Number(a).toLocaleString()}</strong></div>)}
        </div>
        <div className="card">
          <h3>{t.incomeExpenseSummary}</h3>
          <label className="label">{t.selectCurrency}</label>
          <select className="select" value={dashboardCurrency} onChange={e => setDashboardCurrency(e.target.value)}>
            <option value="all">{t.allAddedCurrencies}</option>
            {currencyOptions.map(v => <option key={v} value={v}>{v}</option>)}
          </select>
          <div className="grid2" style={{marginTop:10}}>
            <div className="sumRow"><div><div className="meta">{t.income}</div><div style={{color:"#16a34a",fontWeight:800}}>{dashboardCurrency === "all" ? totalIncome : `${dashboardCurrency} ${totalIncome}`}</div></div></div>
            <div className="sumRow"><div><div className="meta">{t.expense}</div><div style={{color:"#e11d48",fontWeight:800}}>{dashboardCurrency === "all" ? totalExpense : `${dashboardCurrency} ${totalExpense}`}</div></div></div>
          </div>
        </div>
        <SimpleBarChart title="Expense by Category" data={spendingByCategory} colorClass="barBlue" />
        <SimpleBarChart title="Net Flow by Currency" data={currencyFlow} colorClass="barGreen" empty="No currency flow yet." />
        <div className="card">
          <h3>{t.smartAdvice}</h3>
          <div className="info">{advice}</div>
        </div>
        <div className="card">
          <h3>{t.more}</h3>
          <div className="grid2">
            <button className="quick" onClick={() => setTab("reports")}><div className="quickIcon blue">📄</div><div style={{fontSize:12}}>{t.reports}</div></button>
            <button className="quick" onClick={() => setTab("settings")}><div className="quickIcon green">⚙️</div><div style={{fontSize:12}}>{t.settings}</div></button>
          </div>
        </div>
        {deferredPrompt && <button className="btn btnMuted" onClick={installApp}>Install App</button>}
      </>}

      {tab === "assets" && <>
        <div className="card">
          <h3>{t.assets}</h3>
          {assets.length === 0 ? <div className="info">{t.noAssets}</div> : assets.map(a => (
            <div className="item" key={a.id}>
              <div><div className="badge">{assetIcon(a.type)} <strong>{a.name}</strong></div><div className="meta">{a.type} · {a.currency}</div></div>
              <div className="row"><strong>{a.amount}</strong><button className="small smallEdit" onClick={() => editAsset(a)}>Edit</button><button className="small smallDelete" onClick={() => deleteAsset(a.id)}>Delete</button></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h3>{t.addUpdateAsset}</h3>
          <label className="label">{t.assetName}</label><input className="input" value={assetForm.name} onChange={e => setAssetForm({ ...assetForm, name: e.target.value })} />
          <label className="label">{t.assetType}</label>
          <select className="select" value={assetForm.type} onChange={e => setAssetForm({ ...assetForm, type: e.target.value })}>{ACCOUNT_TYPES.map(v => <option key={v} value={v}>{v}</option>)}</select>
          {assetForm.type === "Other" && <><label className="label">{t.customAssetType}</label><input className="input" value={assetForm.customType} onChange={e => setAssetForm({ ...assetForm, customType: e.target.value })} /></>}
          <label className="label">{t.currency}</label><select className="select" value={assetForm.currency} onChange={e => setAssetForm({ ...assetForm, currency: e.target.value })}>{CURRENCIES.map(v => <option key={v} value={v}>{v}</option>)}</select>
          <label className="label">{t.assetAmount}</label><input className="input" type="number" value={assetForm.amount} onChange={e => setAssetForm({ ...assetForm, amount: e.target.value })} />
          <button className="btn btnBlue" style={{marginTop:12}} onClick={saveAsset}>t.addUpdateAsset</button>
        </div>
        <div className="card">
          <h3>{t.transfer}</h3>
          <label className="label">{t.from}</label><select className="select" value={transferForm.from} onChange={e => setTransferForm({ ...transferForm, from: e.target.value })}><option value="">Select source account</option>{assets.map(v => <option key={v.id} value={v.name}>{v.name}</option>)}</select>
          <label className="label">{t.to}</label><select className="select" value={transferForm.to} onChange={e => setTransferForm({ ...transferForm, to: e.target.value })}><option value="">Select destination account</option>{assets.map(v => <option key={v.id} value={v.name}>{v.name}</option>)}</select>
          <label className="label">{t.amount}</label><input className="input" type="number" value={transferForm.amount} onChange={e => setTransferForm({ ...transferForm, amount: e.target.value })} />
          <button className="btn btnGreen" style={{marginTop:12}} onClick={transferAsset}>{t.transfer}</button>
        </div>
      </>}

      {tab === "record" && <>
        <div className="card">
          <h3>{t.record}</h3>
          <div className="grid4" style={{marginBottom:10}}>{allPresets.map(v => <button key={v.id || v.label} className="preset" onClick={() => setRecordForm({ ...recordForm, amount: String(v.amount), currency: v.currency })}>{v.label}</button>)}</div>
          <div className="card" style={{marginTop:10, marginBottom:10, padding:"12px"}}>
            <h3 style={{fontSize:16, marginBottom:10}}>{t.quickAmounts}</h3>
            <div className="grid2">
              <div>
                <label className="label">{t.commonAmount}</label>
                <input className="input" type="number" value={presetForm.amount} onChange={e => setPresetForm({ ...presetForm, amount: e.target.value })} />
              </div>
              <div>
                <label className="label">{t.currency}</label>
                <select className="select" value={presetForm.currency} onChange={e => setPresetForm({ ...presetForm, currency: e.target.value })}>
                  {CURRENCIES.map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
            </div>
            <button className="btn btnBlue" style={{marginTop:10}} onClick={addCustomPreset}>{t.addQuickAmount}</button>
            {customPresets.length > 0 && <div style={{marginTop:10, display:"flex", flexWrap:"wrap", gap:"8px"}}>
              {customPresets.map(v => (
                <button key={v.id} className="preset" onClick={() => removeCustomPreset(v.id)} title={t.remove}>
                  {v.label} ×
                </button>
              ))}
            </div>}
          </div>
          <label className="label">{t.type}</label><select className="select" value={recordForm.type} onChange={e => setRecordForm({ ...recordForm, type: e.target.value })}><option value="Expense">{t.expense}</option><option value="Income">{t.income}</option></select>
          <label className="label">{t.amount}</label><input className="input" type="number" value={recordForm.amount} onChange={e => setRecordForm({ ...recordForm, amount: e.target.value })} />
          <label className="label">{t.currency}</label><select className="select" value={recordForm.currency} onChange={e => setRecordForm({ ...recordForm, currency: e.target.value })}>{CURRENCIES.map(v => <option key={v} value={v}>{v}</option>)}</select>
          <label className="label">{t.account}</label><select className="select" value={recordForm.account} onChange={e => setRecordForm({ ...recordForm, account: e.target.value })}><option value="">{t.selectAccount}</option>{assets.map(v => <option key={v.id} value={v.name}>{v.name}</option>)}</select>
          <label className="label">{t.category}</label><select className="select" value={recordForm.category} onChange={e => setRecordForm({ ...recordForm, category: e.target.value })}>{CATEGORIES.map(v => <option key={v} value={v}>{categoryLabel(v, settings.language)}</option>)}</select>
          {recordForm.category === "Other" && <><label className="label">Custom Category</label><input className="input" value={recordForm.customCategory} onChange={e => setRecordForm({ ...recordForm, customCategory: e.target.value })} /></>}
          <label className="label">{t.note}</label><input className="input" value={recordForm.note} onChange={e => setRecordForm({ ...recordForm, note: e.target.value })} />
          <button className="btn btnBlue" style={{marginTop:12}} onClick={saveRecord}>{editingRecordId ? t.updateRecord : t.saveRecord}</button>
        </div>
        <div className="card">
          <h3>{t.record}</h3>
          <div className="grid2">
            <input className="input" placeholder={t.record} value={search} onChange={e => setSearch(e.target.value)} />
            <select className="select" value={period} onChange={e => setPeriod(e.target.value)}><option value="all">All</option><option value="day">Day</option><option value="week">Week</option><option value="month">Month</option><option value="year">Year</option></select>
          </div>
          <div style={{marginTop:10}}>
            {filteredRecords.length === 0 ? <div className="info">{t.noRecords}</div> :
              filteredRecords.slice(0, 12).map(r => (
                <div className="item" key={r.id}>
                  <div><div className="badge">{categoryIcon(r.category)} <strong>{categoryLabel(r.category, settings.language)}</strong></div><div className="meta">{fmtDate(r.createdAt)} · {r.account || "-"} · {r.currency} · {r.note || "-"}</div></div>
                  <div className="row"><strong style={{color:r.type === "Expense" ? "#e11d48" : "#16a34a"}}>{r.type === "Expense" ? "-" : "+"}{r.amount}</strong><button className="small smallEdit" onClick={() => editRecord(r)}>Edit</button><button className="small smallDelete" onClick={() => deleteRecord(r.id)}>Delete</button></div>
                </div>
              ))}
          </div>
        </div>
      </>}

      {tab === "scan" && (
        <>
          <div className="card">
            <h3>{t.ocrScan}</h3>
            <div className="info" style={{marginBottom:10}}>{t.bestResults}</div>
            <label className="label">{t.ocrMode}</label>
            <select className="select" value={ocrMode} onChange={e => setOcrMode(e.target.value)}>
              <option value="auto">{t.autoDetect}</option>
              <option value="tng">{t.tngMode}</option>
              <option value="bank">{t.bankMode}</option>
              <option value="alipay">{t.alipayMode}</option>
              <option value="wechat">{t.wechatMode}</option>
              <option value="receipt">{t.receiptMode}</option>
            </select>
            <input className="input" ref={fileInputRef} type="file" accept="image/*" onChange={onScanFileChange} />
            {scanPreview && <img className="preview" src={scanPreview} alt="preview" style={{marginTop:12}} />}
            {ocrBusy && <div className="ocrBox">{ocrProgress || "Reading image..."}</div>}
            <div className="sumRow"><span>{t.amount}</span><strong>{scanResult.amount || "-"}</strong></div>
            <div className="sumRow"><span>{t.currency}</span><strong>{scanResult.currency || "-"}</strong></div>
            <div className="sumRow"><span>{t.category}</span><strong>{scanResult.category || "-"}</strong></div>
            <div className="sumRow"><span>{t.note}</span><strong>{scanResult.note || "-"}</strong></div>
            <button className="btn btnBlue" style={{marginTop:10}} onClick={applyScanToRecord}>{t.useInRecordPage}</button>
          </div>
          <div className="card"><h3>{t.ocrTips}</h3><div className="info">For TNG / DuitNow screenshots, choose the matching OCR mode first. This reduces ref-number mistakes and improves amount extraction.</div></div>
          <div className="card">
            <h3>{t.ocrRawText}</h3>
            <div className="rawText">{scanResult.rawText || "No OCR text yet."}</div>
          </div>
        </>
      )}

      {tab === "stats" && <>
        <div className="card">
          <h3>{t.statisticsPeriod}</h3>
          <select className="select" value={statsPeriod} onChange={e => setStatsPeriod(e.target.value)}><option value="all">All</option><option value="day">Day</option><option value="week">Week</option><option value="month">Month</option><option value="year">Year</option></select>
        </div>
        <SimpleBarChart title="Expense by Category" data={spendingByCategory} colorClass="barBlue" />
        <SimpleBarChart title="Net Flow by Currency" data={currencyFlow} colorClass="barGreen" empty="No currency flow yet." />
      </>}

      {tab === "reports" && <div className="card"><h3>{t.reports}</h3><div className="sumRow"><span>Income</span><strong>{reportIncome}</strong></div><div className="sumRow"><span>Expense</span><strong>{reportExpense}</strong></div><div className="sumRow"><span>Savings Rate</span><strong>{reportRate}%</strong></div><button className="btn btnBlue" style={{marginTop:10}} onClick={exportCsv}>Export CSV</button></div>}

      {tab === "settings" && <div className="card"><h3>{t.settings}</h3><label className="label">{t.language}</label><select className="select" value={settings.language} onChange={e => setSettings({ ...settings, language: e.target.value })}><option>English</option><option>中文</option><option>Bahasa Melayu</option></select><label className="label">{t.theme}</label><select className="select" value={settings.theme} onChange={e => setSettings({ ...settings, theme: e.target.value })}><option value="tng">{t.tngTheme}</option><option value="light">{t.light}</option></select><button className="btn btnRed" style={{marginTop:12}} onClick={resetAllData}>{t.resetAllData}</button><div className="info" style={{marginTop:12}}>OCR runs on-device in the browser with Tesseract.js. First OCR load can be slower.</div></div>}

      <BottomNav tab={tab} setTab={setTab} t={t} fabMenuOpen={fabMenuOpen} setFabMenuOpen={setFabMenuOpen} setRecordForm={setRecordForm} />
    </div>
  );
}
